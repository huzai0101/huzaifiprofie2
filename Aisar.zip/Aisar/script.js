/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

var typed = new Typed(".multiple-text", {
    strings: ["Fronted Developer", "Youtuber", "Blogger"],
    typeSpeed: 50,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
})
